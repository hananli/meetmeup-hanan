package com.meetmeup.interfac;

public interface RefreshChatGroup {
	public void onChatRefresh();
}
