package com.meetmeup.interfac;

public interface RefreshEventDetail {
	public void onRefreshDetail();
}
