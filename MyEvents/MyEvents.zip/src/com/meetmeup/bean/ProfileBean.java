package com.meetmeup.bean;

public class ProfileBean {
	    private String user_id;
	    private String user_fname;
	    private String user_lname;
	    private String fb_id;
	    private String image_url;
	    private String yellow_card_status;
	    private String total_user_ratting;
	    private String accept_event;
		public String getUser_id() {
			return user_id;
		}
		public void setUser_id(String user_id) {
			this.user_id = user_id;
		}
		public String getUser_fname() {
			return user_fname;
		}
		public void setUser_fname(String user_fname) {
			this.user_fname = user_fname;
		}
		public String getUser_lname() {
			return user_lname;
		}
		public void setUser_lname(String user_lname) {
			this.user_lname = user_lname;
		}
		public String getFb_id() {
			return fb_id;
		}
		public void setFb_id(String fb_id) {
			this.fb_id = fb_id;
		}
		public String getImage_url() {
			return image_url;
		}
		public void setImage_url(String image_url) {
			this.image_url = image_url;
		}
		public String getYellow_card_status() {
			return yellow_card_status;
		}
		public void setYellow_card_status(String yellow_card_status) {
			this.yellow_card_status = yellow_card_status;
		}
		public String getTotal_user_ratting() {
			return total_user_ratting;
		}
		public void setTotal_user_ratting(String total_user_ratting) {
			this.total_user_ratting = total_user_ratting;
		}
		public String getAccept_event() {
			return accept_event;
		}
		public void setAccept_event(String accept_event) {
			this.accept_event = accept_event;
		}
}
